<?php

define('URL', 'http://localhost/moods/');
