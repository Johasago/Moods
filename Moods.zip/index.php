<?php

require 'libs/bootstrap.php';
require 'libs/controller.php';
require 'libs/view.php';
require 'Model/model.php';


require 'config/routes.php';

$app = new Bootstrap();
