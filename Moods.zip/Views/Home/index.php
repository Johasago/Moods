<div class="container">
<div class ="sliders row">
           
            <h4 class="col-md-3 left">Agitated😬</h4>
            <input type="range" min="0" max="2" value="1" class="col-md-6 slider" id="slider1" onchange="loadMovies(this.value)">
            <h4 class="col-md-3">😎Calm</h4>
            <h4 class="col-md-3 left">Happy😀</h4>
            <input type="range" min="3" max="5" value="4" class="col-md-6 slider" id="slider2" onchange="loadMovies(this.value)">
            <h4 class="col-md-3">😢Sad</h4>
           
            <h4 class="col-md-3 left">Tired😴</h4>
            <input type="range" min="6" max="8" value="7" class="slider col-sm-6" id="slider3" onchange="loadMovies(this.value)">
            <h4 class="col-md-3">😲Wide Awake</h4>

            <h4 class="col-md-3 left">Scared😱</h4>
            <input type="range" min="9" max="11" value="10" class="slider col-sm-6" id="slider4" onchange="loadMovies(this.value)">
            <h4 class="col-md-3">😈Fearless</h4>

        </div>



           <div class="card-deck">
<div id="1" class="card" >
  <img class="card-img-top" src="images/placeholder.jpg" alt="No Content">
  <div class="card-body">
      <h5 class="card-title">No content</h5>
  </div>
</div>
<div id="2" class="card" >
  <img class="card-img-top" src="images/placeholder.jpg" alt="No Content">
  <div class="card-body">
      <h5 class="card-title">No content</h5>
  </div>
</div>
<div id="3" class="card" >
  <img class="card-img-top" src="images/placeholder.jpg" alt="No Content">
  <div class="card-body">
      <h5 class="card-title">No content</h5>
  </div>
</div>
<div id="4" class="card" >
  <img class="card-img-top" src="images/placeholder.jpg" alt="No Content">
  <div class="card-body">
      <h5 class="card-title">No content</h5>
  </div>
</div>
<div id="5" class="card" >
  <img class="card-img-top" src="images/placeholder.jpg" alt="No Content">
  <div class="card-body">
      <h5 class="card-title">No content</h5>
  </div>
</div>
</div>
       </div>



    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T" crossorigin="anonymous"></script>
   
    </body>
</html>
