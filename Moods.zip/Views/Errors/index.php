<div class="container">
<h2><?php echo $this->msg; ?></h2>

</div>